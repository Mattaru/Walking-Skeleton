### Skeleton:
#### ```server``` - DENO+HONO
#### ```client``` - SVELT
#### ```db``` - PSQL+FLYWAY
#### ```e2e-tests``` - PLAYWRIGHTS.
